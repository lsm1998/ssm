package com.lsm1998.ibatis.builder;

/**
 * @作者：刘时明
 * @时间：18-12-21-下午3:03
 * @说明：
 */
public abstract class MyBaseBuilder
{
    
}
