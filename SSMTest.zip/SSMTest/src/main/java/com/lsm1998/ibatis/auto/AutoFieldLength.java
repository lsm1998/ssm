package com.lsm1998.ibatis.auto;

/**
 * @作者：刘时明
 * @时间：18-12-24-上午10:59
 * @说明：字段默认长度
 */
public class AutoFieldLength
{
    public static final int INT_LEN = 11;
    public static final int VARCHAR_LEN = 11;
    public static final int CHAR_LEN = 1;
}
