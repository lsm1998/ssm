package com.lsm1998.ibatis.enums;

/**
 * @作者：刘时明
 * @时间：18-12-24-下午2:32
 * @说明：
 */
public enum AutoIncrement
{
    TRUE,FALSE
}
