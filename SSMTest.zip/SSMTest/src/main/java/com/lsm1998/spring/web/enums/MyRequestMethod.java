package com.lsm1998.spring.web.enums;

/**
 * @作者：刘时明
 * @时间:2018/12/20-18:15
 * @说明：请求类型枚举
 */
public enum MyRequestMethod
{
    GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE
}
