package com.lsm1998.spring.aop.enums;

/**
 * @作者：刘时明
 * @时间：19-1-8-下午4:28
 * @说明：
 */
public enum Type
{
    PRINT, LOGS, JDBC
}
