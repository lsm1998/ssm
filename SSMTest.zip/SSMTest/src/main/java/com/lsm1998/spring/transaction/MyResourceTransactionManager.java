package com.lsm1998.spring.transaction;

/**
 * @作者：刘时明
 * @时间:2018/12/23-21:43
 * @说明：资源事务管理器接口
 */
public interface MyResourceTransactionManager
{
    Object getResourceFactory();
}
